define([
    'ko'
], function (ko) {
    'use strict';

    return {
        isLoading: ko.observable(false)
    };
});
